---
created: 2022-05-07 16:22
modified: 星期六 7日 五月 2022 16:22:13
tags: 
parent:
related: 
reference:
---



This is a strategy in SPT, and especially for [[SIS]]



#### Follow #todo 
1. [ ] 