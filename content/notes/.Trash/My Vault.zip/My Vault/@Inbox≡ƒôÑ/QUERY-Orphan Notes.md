---
created: 2022-05-07 17:19
modified: 星期六 7日 五月 2022 17:19:39
tags: 
parent:
related: 
reference:
---


```dataview
list from ""
where length(file.inlinks)=0 and length(file.outlinks)=0
sort file.name
```



#### Follow #todo 
1. [ ] 