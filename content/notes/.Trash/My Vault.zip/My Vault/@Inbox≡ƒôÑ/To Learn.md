# [[ToLearn List]]

20200819
#ToLearn 

20200905
#ToLearn 供给侧改革

20200905 contract research organizations (CROs) performed functions from initial product development and clinical trial implementation to preparation of applications for regulatory approval.

- #todo/tolearn
- [ ] 文件夹整理的[[PARA方法]]
- [ ] [[Maps of Content]] (MOC)

