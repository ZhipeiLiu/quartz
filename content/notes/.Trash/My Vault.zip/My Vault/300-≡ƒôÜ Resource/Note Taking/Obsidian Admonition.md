Types
-   note
-   abstract, summary, tldr
-   info, todo
-   tip, hint, important
-   success, check, done
-   question, help, faq
-   warning, caution, attention
-   failure, fail, missing
-   danger, error
-   bug
-   example
-   quote, cite

Syntax

2. 在代码块中填入 `title:` 来更改默认的渲染的标题
3. 在代码块中填入 `collapse:` 来更改默认的渲染的折叠情况
4. 在代码块中填入 `icon:` 来更改默认的渲染的图标
5. 在代码块中填入 `color:` 

Ad in Ad
```ad-note
title: Nested Admonitions
collapse: open

Hello!

~~~ ad-note
    title: This admonition is nested.
    This is a nested admonition!
    !!! ad-warning
        title: This admonition is closed.
        collapse: close



This is in the original admonition.

```

Syntax 2:
					
>[!quote]
>HIHI


>[!INFO]
>Here's a callout block.