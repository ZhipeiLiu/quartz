

control + P
chart
```chart
type: line
labels: [1,2,3,4]
series:
  - title: HIHI
    data: [1,44,73,2]
  - title: sadf
    data: [123,3,45,75]
tension: 0.34
width: 80%
labelColors: false
fill: true
beginAtZero: false
```