
- Four natively supported YAML keys
	-   `tags` ([more information](https://help.obsidian.md/How+to/Working+with+tags))
	-   `aliases` ([more information](https://help.obsidian.md/How+to/Add+aliases+to+note))
	-   `cssclass`
	-   `publish` ([Publish and unpublish notes > Automatically select notes to publish](https://help.obsidian.md/Obsidian+Publish/Publish+and+unpublish+notes#Automatically%20select%20notes%20to%20publish) and [Publish and unpublish notes > Ignore notes](https://help.obsidian.md/Obsidian+Publish/Publish+and+unpublish+notes#Ignore%20notes))

## Personal Preference - Standardization
- [[TP-Diary Template]] 
	- created:
	- tags:
- Notes
	- created:
	- tags: 
	- parent:
	- related: 
	- reference:
- 
- Meeting Minutes
	- created:
	- tags:
	- participants:
	- location: 

