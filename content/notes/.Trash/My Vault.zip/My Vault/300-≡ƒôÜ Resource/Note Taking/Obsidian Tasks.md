![[Pasted image 20220506202644.png]]

#### 所有未完成

```tasks
not done
sort by due
```


#### 明日到期
```tasks
not done
due on tomorrow
sort by due
```


#### 今日到期

```tasks
due before tomorrow
sort by due
```

#### 昨日未完成

```tasks
not done
due yesterday
sort by due
```

#### 一周内到期
```tasks
not done
due before {{next week}}
```

#### 本月内任务
```tasks
not done
due before {{next month}}
sort by due
```

#### 所有已完成
```tasks
done
```
