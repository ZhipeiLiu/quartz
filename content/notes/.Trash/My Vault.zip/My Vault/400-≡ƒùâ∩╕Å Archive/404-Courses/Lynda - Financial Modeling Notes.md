# [[Lynda - Financial Modeling Notes]] 



