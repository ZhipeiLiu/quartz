# [[20200918 Ideas in Contemporary Art - Class Notes]]

Notes: 
		[[003 Ideas in Contemporary Art]] 
tags: #literature-note #art #contemporary
Source: Class


Are Review --> know the language - know how to communicate 

20200925
- Bruce Nauman - form, range of materials
	- conceptual artist
	- actions exist in space and time
	- "Make me think me" - by thinking about the work - I think about me - I embody the artwork - this process makes the art


- Andy Warhol - the name reminds of pop art





A entails B --> 