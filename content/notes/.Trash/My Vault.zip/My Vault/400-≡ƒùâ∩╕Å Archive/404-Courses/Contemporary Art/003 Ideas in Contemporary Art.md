[[003 Ideas in Contemporary Art]]

[[20200918 Ideas in Contemporary Art - Class Notes]]