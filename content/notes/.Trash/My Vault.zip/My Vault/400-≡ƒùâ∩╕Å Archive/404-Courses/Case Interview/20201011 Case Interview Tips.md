# [[20201011 Case Interview Tips]]
Related notes: [[100 Case Interview Notes]]
source: Victor Cheng Case Interview videos 12 /12
tags: #literature-note #case-interview #case


- Find the trend
- Company-specific or Industry-wide
- Totals and Averages are very misleading
	- Always segment your metrics
- If you don't segment, you miss the whole point
- Think out loud
- Ignore your previous knowledge and only use data from the case