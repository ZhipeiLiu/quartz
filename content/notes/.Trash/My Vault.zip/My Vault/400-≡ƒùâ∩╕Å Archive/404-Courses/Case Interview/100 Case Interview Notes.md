# [[100 Case Interview Notes]]

1. [[20201011 Case Interview Basics & Case Interviewer Mindset]]
2. [[20201011 How to Open, Analyze and Close a Case Interview]]
3. [[20201011 Case Interview Frameworks]]
4. [[20201010 Case Interview - M&A]]
5. [[20201011 Case Interview Tips]]