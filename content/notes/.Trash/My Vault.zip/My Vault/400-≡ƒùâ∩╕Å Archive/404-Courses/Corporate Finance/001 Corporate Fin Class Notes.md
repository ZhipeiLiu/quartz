# [[001 Corporate Fin Class Notes]]

[[20200831 Financial Statement Analysis]]
[[20200911 NPV & Other Investment Rules]]
[[20200912 Making Capital Investment Decisions]]
[[20200927 Risk Analysis, Real Options & Capital Budgeting]]
--- 
Midterm

[[20201003 Stock Valuation]]
[[20201010 Risk, Cost of Capital, & Valuation]]
[[20201017 Intro to Capital Structure]]
[[20201024 Capital Structure & Limits to the Use of Debt]]
---
Midterm
[[20201109 Valuation & Capital Budgeting for the Levered Firm]]










