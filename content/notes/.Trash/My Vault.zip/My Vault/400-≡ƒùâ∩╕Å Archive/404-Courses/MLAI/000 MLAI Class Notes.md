# [[000 MLAI Class Notes]]

## 20200902 Class 2
Reading notes: [[20200901 2019_MIT_BCG_AI]]

## 202009 Class 3
Reading note:[[20200904 What is AI and ML]]

  

```dataview
table created
from "Diary"
```

