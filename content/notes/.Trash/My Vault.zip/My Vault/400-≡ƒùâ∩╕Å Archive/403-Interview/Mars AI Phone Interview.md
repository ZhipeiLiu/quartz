Hi my name is Zhipei Liu, a senior at Boston College, I study Finance and Business Analytics. I am involved in BikeBC, an oncampus bikeshare program. I am also a member of hte Jenks LP, where we completed a social innovation project and made it sustainable. I am also a research assistant for Professor Nancy Xu from the Finance Department. My range of involvements makes me adaptive to different leadership and teamwork styles and make myself competent in a range of roles. 



Five Principles (Quality, Responsibility, Mutuality, Efficiency, Freedom)


核心能力：
**领导力**
快速**学习能力** - 举一反三 总结反思的能力 transferrable skills - 总结能力 - documentation+summary
创新能力
商业敏锐度
好奇心/开放的心态 - 找关联 找方向 方向的成长
寻求反馈d


岗位轮岗：
机会很多、舞台够大，有机会找到自己喜欢的方向也同时有机会探索不同的职能

城市轮岗：
接触不同地区 - 不同观点 - 成长