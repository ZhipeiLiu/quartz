source: call with Andrew Malley
notes: 
tags: #career #deloitte #bc #back2bc

# [[202007092219 Call with Andrew Malley]]

## Mentor Profile
### Andrew Malley
**Meeting time**: Eastern Time before 1pm (only)

**Location**: based out of the Detroit/Boston offices (no permanent home at the moment)

**Role**: Consultant / Business Technology Analyst 

**Current company**: Deloitte

**Current practice**: Emerging ERP (working with large-scale enterprises on digital finance transformations)

**Areas of interest**: Strategic Planning and Chart of Accounts (financial) design

**Contact info:**
- Mobile: +1 857 324 2263
- Email: anmalley@deloitte.com



## Meeting on 2020/7/9
### Preparation
Questions to ask:
- How you start it after graduation?
- Why did you choose a tech consulting career and Deloitte specifically?
- What is it like to work in two offices? What are some pros and cons?
- What was your most valuable BC experence?

### Notes
big bc fan
16
from detroit
3 years in bos after graduation
- oracle - finance software ERP
- Deloitte Consulting - higher ed practice
	- emerging ERP - workday 
- ECON & Muisc major 
- 































