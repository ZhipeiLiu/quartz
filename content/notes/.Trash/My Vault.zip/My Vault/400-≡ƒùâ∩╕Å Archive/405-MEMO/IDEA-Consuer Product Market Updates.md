---
created: 2022-05-07 16:28
modified: 星期六 7日 五月 2022 16:28:02
tags: 
parent:
related: 
reference:
---

channel idea：

Consumer products market updates with consumer experience (key element) or technical details explained / as a column or a video channel

competitive advantage:
Develop interesting storylines instead of copy pasting arguments
Visualization
Connecting to consumer / resonation
Technicals explained
Work with product testing / [[Store Visits]]

Purpose: 
add credibility to personal brand on understanding the [[FMCG]] and general consumer goods industry - towards consulting kind of
Build foundations for entrepreneurship initiatives after [[Mars]]

Verticals: 
新消费食品/饮品/[[Pet Food]]/精品饮品（酒精/咖啡）

Reference: 
36Kr
浪潮新消费
FBIF





#### Follow #todo 
1. [ ] 