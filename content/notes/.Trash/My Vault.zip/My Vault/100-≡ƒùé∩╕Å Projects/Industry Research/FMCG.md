---
created: 2022-05-07 16:31
modified: 星期六 7日 五月 2022 16:31:44
tags: 
aliases: [Fast Moving Consumer Goods, 快消, 快消品, 快速消费品, 快消行业]
parent:
related: 
reference:
---







#### Follow #todo 
1. [ ] 