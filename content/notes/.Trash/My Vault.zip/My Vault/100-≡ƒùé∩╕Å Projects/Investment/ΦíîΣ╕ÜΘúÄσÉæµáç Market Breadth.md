source: [B站 - MarketBreadth0704 美股 | A股 | 比特币 | 交易笔记 | 牛市反身性扭转预期 | FED Won't Let the Market Down | Bitcoin Up!](https://www.bilibili.com/video/BV1J5411Y7iB/)
tags: #investing #industry #market #index
notes: [[202006141448 Industry Research]]

# [[行业风向标 Market Breadth]]

## 市场温度图：
![[MarketBreadth0704.png]]

[[TO-DO]]
- [ ] 视频多去看几遍 再做笔记 这个视频很值得看
- [ ] Make a spreadsheet something like this
- [ ] 