Notes: 
		[[202006141306 How to pick public companies|Pick public companies]] 
tags: #permanent-note #sector #industry 

# [[202006141448 Industry Research|Industry Research]]


## Table of Contents:
Industry analysis in practice
电影业
房地产

### Industry analysis in practice
[[20200905 The Five Competitive Forces That Shape Strategy]]

### 电影业
_Source: [知乎](https://www.zhihu.com/question/27949230/answer/293377232)_
备受资本追捧, 但是电影业的现金流不是很好
    早期投资非常大, 回款慢, 要等公映之后扣完发行, 导演等费用才能获得收入.
    	电影行业亏损几率高, 很难成为一个好的行业.


### 房地产
_Source: [知乎](https://www.zhihu.com/question/27949230/answer/293377232)_
传统行业, 但是回款快
    出钱买块地, 房子没盖完就能预售\回款了.
    银行贷款+卖房款=资金使用效率极高
    PE比较低, 行业比较成熟, 未来企业利润增长空间有限, 很难有爆发式的增长
    楼市市场里钱uu越多, 流动性越好, 价格自然会被炒上去
    
## 制造业
PE比较低, 行业比较成熟, 未来企业利润增长空间有限, 很难有爆发式的增长

## 互联网行业
PE比较高, 早期利润不高, 但是增长空间很大, 当前利润不能衡量企业的真正价值.


## 食品饮料
[[202007060057 植物肉市场研报|植物肉市场]]