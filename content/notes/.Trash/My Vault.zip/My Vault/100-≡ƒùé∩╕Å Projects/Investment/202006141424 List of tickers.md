Notes:
tags: #dictionary

# [[202006141424 List of tickers|List of tickers]]

[[SZ000626]]：如意集团