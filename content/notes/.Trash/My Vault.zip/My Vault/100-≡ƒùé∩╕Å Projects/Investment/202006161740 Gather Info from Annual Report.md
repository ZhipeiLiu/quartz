# [[Gather Info from Annual Report]]



从哪里获取? 
Refer to [[年报]]


## 信息

![[v2-5b1039a011571fc6d6c1b3ded17c7461_1440w.jpg]]

![[v2-dcbce8a03e525c49bead836188fc647d_1440w.jpg]]
- 看会计师事务所, 连任年数多的更稳定, 如果经常换(从往年年报中看出来)就不靠谱
- 公司业务分析
- 公司供应链\商业模式分析(采购\生产\销售)