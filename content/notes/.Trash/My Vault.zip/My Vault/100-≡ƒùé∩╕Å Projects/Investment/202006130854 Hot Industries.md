# [[202006130854 Hot Industries]]

## Ideas from 李自然说
- 开源商业模式 [^1]
- 远程办公/协同办公
- 后台即服务（api）Go to Market
- 云原生
- 中国新消费 [^2]
- 中国模式出海
- AR [^3]



## Lone Capital
[[行业风向标 Market Breadth]]


[^1]: 获客成本低是一个优势
[^2]: 吃喝玩乐
[^3]: 苹果AR生态