source: [[20200614130636 How to pick public companies|pick public companies]]
relevant notes:
tags: #permanent-note #finance #investing 
	
# [[20200614132459 Construct a portfolio|Construct a portfolio]]

