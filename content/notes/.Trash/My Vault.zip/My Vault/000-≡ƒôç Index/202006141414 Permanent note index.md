#permanent-note

# [[ 20200614141409 Permanent note index|Permanent note index]]



## Finance
[[202006141324 Constructing a portfolio|Constructing a portfolio]] 
[[202006130854 Hot Industries|风口领域]]
[[202006141448 Industry Research|Industry Research]] 


## Life
